const { CognitoIdentityProviderClient, AdminCreateUserCommand } = require('@aws-sdk/client-cognito-identity-provider');
const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
const { DynamoDBClient, PutItemCommand } = require('@aws-sdk/client-dynamodb');

const cognitoClient = new CognitoIdentityProviderClient({ region: 'us-east-1' });
const sesClient = new SESClient({ region: 'us-east-1' });
const dynamoClient = new DynamoDBClient({ region: 'us-east-1' });

exports.handler = async (event) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Content-Type': 'application/json'
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const { companyName, adminEmail, adminName, plan } = JSON.parse(event.body);
    
    console.log('Registration request:', { companyName, adminEmail, adminName, plan });

    // 1. Create Cognito user (simplified - no custom attributes)
    const createUserParams = {
      UserPoolId: process.env.COGNITO_USER_POOL_ID,
      Username: adminEmail,
      MessageAction: 'SUPPRESS',
      UserAttributes: [
        { Name: 'email', Value: adminEmail },
        { Name: 'name', Value: adminName },
        { Name: 'email_verified', Value: 'true' }
      ]
    };

    await cognitoClient.send(new AdminCreateUserCommand(createUserParams));
    console.log('Cognito user created successfully');

    // 2. Save to DynamoDB
    const registrationDate = new Date().toISOString();
    const trialDays = parseInt(process.env.TRIAL_DAYS) || 14;
    const expirationDate = new Date(Date.now() + trialDays * 24 * 60 * 60 * 1000).toISOString();
    
    const dynamoParams = {
      TableName: process.env.DYNAMODB_TABLE,
      Item: {
        email: { S: adminEmail },
        registrationDate: { S: registrationDate },
        companyName: { S: companyName },
        adminName: { S: adminName },
        plan: { S: plan },
        instanceUrl: { S: process.env.INSTANCE_URL },
        expirationDate: { S: expirationDate },
        status: { S: 'active' },
        username: { S: 'admin' },
        password: { S: 'admin123' }
      }
    };

    await dynamoClient.send(new PutItemCommand(dynamoParams));
    console.log('DynamoDB record saved successfully');

    // 3. Send welcome email
    const expirationDateFormatted = new Date(expirationDate).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const emailParams = {
      Source: process.env.SES_FROM_EMAIL,
      Destination: { ToAddresses: [adminEmail] },
      Message: {
        Subject: { Data: 'Welcome to MOAMALAT - Your Instance is Ready!' },
        Body: {
          Html: {
            Data: `
              <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
                <h1 style="color: #6366f1;">Welcome to MOAMALAT!</h1>
                <p>Dear ${adminName},</p>
                <p>Your MOAMALAT instance is ready and valid for ${trialDays} days:</p>
                
                <div style="background: #f8fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                  <h3 style="margin-top: 0; color: #1e293b;">Instance Access Details</h3>
                  <ul style="list-style: none; padding: 0;">
                    <li style="margin: 10px 0;"><strong>URL:</strong> <a href="${process.env.INSTANCE_URL}" style="color: #6366f1;">${process.env.INSTANCE_URL}</a></li>
                    <li style="margin: 10px 0;"><strong>Username:</strong> admin</li>
                    <li style="margin: 10px 0;"><strong>Password:</strong> admin123</li>
                    <li style="margin: 10px 0;"><strong>Valid until:</strong> ${expirationDateFormatted}</li>
                  </ul>
                </div>

                <p>Start managing your correspondence today!</p>
                
                <hr style="margin: 30px 0; border: none; border-top: 1px solid #e2e8f0;">
                <p style="color: #64748b; font-size: 14px;">
                  Need help? Contact us at <a href="mailto:support@dataserve.com.sa" style="color: #6366f1;">support@dataserve.com.sa</a>
                </p>
                <p style="color: #64748b; font-size: 12px;">© 2024 DataServe - MOAMALAT SaaS Platform</p>
              </div>
            `
          },
          Text: {
            Data: `
Welcome to MOAMALAT!

Dear ${adminName},

Your MOAMALAT instance is ready and valid for ${trialDays} days:

Instance Access Details:
- URL: ${process.env.INSTANCE_URL}
- Username: admin
- Password: admin123
- Valid until: ${expirationDateFormatted}

Start managing your correspondence today!

Need help? Contact us at support@dataserve.com.sa

© 2024 DataServe - MOAMALAT SaaS Platform
            `
          }
        }
      }
    };

    await sesClient.send(new SendEmailCommand(emailParams));
    console.log('Welcome email sent successfully');

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        message: 'Registration successful! Check your email for access details.',
        instanceUrl: process.env.INSTANCE_URL,
        expirationDate: expirationDateFormatted
      })
    };

  } catch (error) {
    console.error('Registration error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        success: false,
        error: error.message || 'Registration failed. Please try again.'
      })
    };
  }
};
